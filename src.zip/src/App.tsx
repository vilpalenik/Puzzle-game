import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { GameProvider } from './context/GameContext';
import HomePage from './pages/HomePage';
import LevelPage from './pages/LevelPage';
import GamePage from './pages/GamePage';
import ControlsPage from './pages/ControlsPage';
import LevelEditor from './pages/LevelEditor';

const App: React.FC = () => {
  return (
    <GameProvider>
      <HashRouter>
        <div className="min-h-screen flex flex-col">
          <Routes>
            <Route path="/editor" element={<LevelEditor />} />
            <Route path="/" element={<HomePage />} />
            <Route path="/levels" element={<LevelPage />} />
            <Route path="/game/:id" element={<GamePage />} />
            <Route path="/controls" element={<ControlsPage />} />
          </Routes>
        </div>
      </HashRouter>
    </GameProvider>
  );
};

export default App;